import { Props } from "../player-app";
interface ClientProps extends Props {
    class?: string;
}
export declare function Client(props: ClientProps): import("preact").VNode<any> | import("preact").VNode<any>[];
export {};
